
import sys
import json

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kinesis import KinesisUtils, InitialPositionInStream
from datetime import datetime

if __name__ == "__main__":

    #sc = SparkContext(appName="PythonStreamingKinesisWordCountAsl")
	sc = SparkContext.getOrCreate()
    ssc = StreamingContext(sc, 1)
    applicationName, streamName, endpointUrl, regionName = "Myapp","DeliveryLogStream","https://kinesis.eu-west-1.amazonaws.com","eu-west-1"
    print("appname is" + applicationName + streamName + endpointUrl + regionName)
    lines = KinesisUtils.createStream(
        ssc, applicationName, streamName, endpointUrl, regionName, InitialPositionInStream.LATEST, 2)

    lines.pprint()

    def format_sample(x):
        data = json.loads(x)
        # data['doc_id'] = data.pop('timestamp')
        # return (data['doc_id'], json.dumps(data))
        return (datetime.now(), json.dumps(data))

    parsed = lines.map(lambda x: format_sample(x))
    parsed.pprint()


    ssc.start()
    ssc.awaitTermination()
	