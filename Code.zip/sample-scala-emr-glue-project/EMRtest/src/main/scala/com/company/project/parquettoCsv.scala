package com.company.project

import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.SparkSession

object parquettoCsv {
   def main(sysArgs: Array[String]){
      val spark = SparkSession.builder().appName("MyTestApp").getOrCreate()
      spark.sparkContext.hadoopConfiguration.set("yarn.nodemanager.pmem-check-enabled","false")
      spark.sparkContext.hadoopConfiguration.set("yarn.nodemanager.vmem-check-enabled","false")
      val df1=spark.read.options(Map("delimiter"->",","header"->"true","inferSchema"->"true","escape"->"\"","quote"->"\"")).csv(sysArgs(0))
      df1.write.mode("overwrite").parquet("s3://deliverylogs54544322/parquet")
  }
}