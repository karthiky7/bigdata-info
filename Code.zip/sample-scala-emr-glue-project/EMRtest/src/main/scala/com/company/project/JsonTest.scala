package com.siemens.logdelivery

import java.io.InputStream

import scala.collection.JavaConverters.mapAsJavaMapConverter
import scala.util.parsing.json.JSON

import org.apache.spark.SparkContext
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.SparkSession

import com.amazonaws.auth.BasicSessionCredentials
import com.amazonaws.services.glue.GlueContext
import com.amazonaws.services.glue.log.GlueLogger
import com.amazonaws.services.glue.util.GlueArgParser
import com.amazonaws.services.glue.util.Job
import com.amazonaws.services.glue.util.JsonOptions
import com.amazonaws.services.s3.AmazonS3Client
import org.apache.spark.SparkConf


object JsonTest {
  def formatHeader(columnName:String)={
   var newColumnName = "([A-Z](?=[a-z]))".r.replaceAllIn(columnName, "_$1")
   newColumnName= "((?<=[a-z0-9])[A-Z])".r.replaceAllIn(newColumnName, "_$1").toLowerCase()
   newColumnName= "[^\\w]".r.replaceAllIn(newColumnName, "_")
   newColumnName= "^(_+)".r.replaceAllIn(newColumnName, "")
   newColumnName= "(_+)$".r.replaceAllIn(newColumnName, "")
   newColumnName= "(_{2,})".r.replaceAllIn(newColumnName, "_") 
   newColumnName
  }
  def readConfig()={
     val key="ASIAQM4J32K7"
     val secret="2ufy7Y+6eHuAdTpPk8/wbhXBfVF"
     val token="FwoGZXEJL//////////wEYeaAWCsQRE7JaITpUHfk1/zqcG9cIOEaZTVv6tgDeiyNLT530QmWsVI3lJUsQwjRnKmtF2PSYbHXTyXsqGkDrJ27HQxjC5zXQKqhcLRbxeBeocYsFP0kdLSh20P0ee1A061NJBYp0PkUMGcDTUsTuw60+1IpeIK9Ok33wt0Nv2gGe8TH7xIuxCrPT48AzXLwRJJwuDUXEx3fr8VZ1uUAhRqrEwNJGZZDREKRYplOIm4btGsNZMAW2KyjgzaD4BTIt12gS0YV7Y6EBdhFC94/29VoQw0HP9/4nSzr3hoLGD1HMiFE1zZ1c9nYgzEeo"
     val credentials = new BasicSessionCredentials(key,secret,token)
     val client = new AmazonS3Client(credentials)
     val inputStream: InputStream =client.getObject("data-analytics-config-dev", "p2p-logistics/etl/conf/landing_to_staging.json").getObjectContent
  
     val s=scala.io.Source.fromInputStream(inputStream).getLines().mkString
     val json=JSON.parseFull(s).get.asInstanceOf[Map[String, Any]]("Source")
     json
  }
  def csvToParquet(jobconfig:Map[String, Any],glueContext: GlueContext,envsuffix:String){
    
      val log = new GlueLogger()
      //reading input data from landing bucket
      val formatOptions=jobconfig("format").asInstanceOf[Map[String, Any]]
      val inputDynamicFrame=glueContext.getSourceWithFormat(connectionType="s3",format="csv" , options = JsonOptions(Map("paths" -> Array(jobconfig("landing_prefix").asInstanceOf[String].replace("{suffix}",envsuffix).toString)))
                       ,formatOptions=JsonOptions(Map("separator" -> formatOptions("sep"), "withHeader" -> formatOptions("header"), "escaper" -> formatOptions("escape") , "quoteChar" -> formatOptions("quote")))
                       ,  transformationContext="bpaSession").getDynamicFrame()
      log.info(s"Reading from landing bucket is completed ${jobconfig("landing_prefix").asInstanceOf[String]}")
  
      var inputDataFrame=inputDynamicFrame.toDF()
      // changing column header names for parquet write
      inputDataFrame.columns.foreach(oldcolumnname => inputDataFrame = inputDataFrame.withColumnRenamed(oldcolumnname, formatHeader(oldcolumnname)))
      log.info("Formatted column names for parquet write ")
      jobconfig("nulls").asInstanceOf[List[String]].foreach(nullreplace=>inputDataFrame=inputDataFrame.na.replace(inputDataFrame.columns,Map(nullreplace->"")))
      
      
      //writing into staging bucket
      val optionsMap=Map("header"->"true","sep" -> ";" , "escape"->"\"")
      inputDataFrame.coalesce(jobconfig("partition_count").asInstanceOf[Double].toInt).write.options(optionsMap).mode(SaveMode.Append).format("csv").save("C:\\rpa-logs\\test\\statiscdata")
      log.info(s"Writing to staging bucket is completed : ${jobconfig("landing_prefix").asInstanceOf[String]} ")
   
     
    }
   
  def main(sysArgs: Array[String]){
    System.setProperty("hadoop.home.dir", "C:\\rpa-logs\\");
     val log = new GlueLogger()
      val sparkConfig=new SparkConf().setMaster("local").setAppName("MyApp")
      
    val sparkContext: SparkContext = new SparkContext(sparkConfig)
    try{
      val glueContext: GlueContext = new GlueContext(sparkContext,30,1)
      glueContext.sc.hadoopConfiguration.set("fs.s3a.aws.credentials.provider", "org.apache.hadoop.fs.s3a.TemporaryAWSCredentialsProvider")
      glueContext.sc.hadoopConfiguration.set("fs.s3a.access.key","ASIOHM4J32K7")
      glueContext.sc.hadoopConfiguration.set("fs.s3a.secret.key","2ufyaUwZWpwbhXBfVF")
      glueContext.sc.hadoopConfiguration.set("fs.s3a.session.token","FwoGEJL//////////wEaDOuvY/FjK6AYDYeaAWCsQRE7JaITpUHfk1/zqcG9cIOEaZTVv6tgDeiyNLT530QmWsVI3lJUsQwjRnKmtF2PSYbHXTyXsqGkDrJ27HQxjC5zXQKqhcLRbxeBeocYsFP0kdLSh20P0ee1A061NJBYp0PkUMGcDTUsTuw60+1IpeIK9Ok33wt0Nv2gGe8TH7xIuxCrPT48AzXLwRJJwuDUXEx3fr8VZ1uUAhRqrEwNJGZZDREKRYplOIm4btGsNZMAW2KyjgzaD4BTIt12gS0YV7Y6EBdhFC94/29VoQw0HP9/4nSzr3hoLGD1HMiFE1zZ1c9nYgzEeo")
      glueContext.sc.hadoopConfiguration.set("fs.s3a.server-side-encryption-algorithm","aws:kms")
    
      val sparkSession: SparkSession = glueContext.getSparkSession
 
      // specifying spark configuration
      sparkSession.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      sparkSession.conf.set("spark.network.timeout ",800)
      
      glueContext.sc.hadoopConfiguration.set("yarn.nodemanager.vmem-check-enabled","false")
      glueContext.sc.hadoopConfiguration.set("yarn.nodemanager.pmem-check-enabled","false")
      
      val filterArgs = Seq("JOB_NAME", "config_bucket", "config_object", "env_suffix","format")
      //GlueArgs Parser happens
      //val args = GlueArgParser.getResolvedOptions(sysArgs, filterArgs.toArray)
      
      //initiating job object for bookmarking
      //Job.init(args("JOB_NAME"), glueContext, args.asJava)
      log.info("Intiated GlueContext and all job parameters")
      
      readConfig().asInstanceOf[Map[String, Any]].foreach(listofjobs=>{
      println(listofjobs._1)
      csvToParquet(listofjobs._2.asInstanceOf[Map[String, Any]],glueContext,"-dev")
      })
       Job.commit()
    }
        catch {
       case e: Exception =>{ 
         log.error(s"Glue job got failed : ${e.getMessage}")
       }
     
    }
    finally{
      log.info("Stopping spark context")
      sparkContext.stop()
    }
  }
      

}