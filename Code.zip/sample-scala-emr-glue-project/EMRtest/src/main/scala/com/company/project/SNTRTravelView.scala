package com.siemens.logdelivery

import scala.collection.JavaConverters.mapAsJavaMapConverter

import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.FileUtil
import org.apache.hadoop.fs.Path
import org.apache.log4j.Logger
import org.apache.spark.SparkContext
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.SparkSession

import com.amazonaws.services.glue.GlueContext
import com.amazonaws.services.glue.util.GlueArgParser
import com.amazonaws.services.glue.util.Job
import com.amazonaws.services.glue.log.GlueLogger

object SNTRTravelView {
  def main(sysArgs: Array[String]){
     val log = new GlueLogger()
    val sparkContext: SparkContext = new SparkContext()
    var jobId=""
    try{
      val glueContext: GlueContext = new GlueContext(sparkContext)
      val sparkSession: SparkSession = glueContext.getSparkSession
 
      sparkSession.conf.set("spark.sql.autoBroadcastJoinThreshold" , "500000000")
      sparkSession.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      sparkSession.conf.set("spark.sql.broadcastTimeout",1200)
      sparkSession.conf.set("spark.network.timeout",800)
      //sparkSession.conf.set("spark.sql.shuffle.partitions",100)
      glueContext.sc.hadoopConfiguration.set("yarn.nodemanager.vmem-check-enabled","false")
      glueContext.sc.hadoopConfiguration.set("yarn.nodemanager.pmem-check-enabled","false")
      
      val filterArgs = Seq("JOB_NAME","partition_count","format","bucket_name","landing_folder_sntr_travels","landing_folder_fy_month","landing_folder_commodity_mapping","landing_folder_country","staging_folder")
      //GlueArgs Parser happens
      val args = GlueArgParser.getResolvedOptions(sysArgs, filterArgs.toArray)
      jobId= args("JOB_RUN_ID")
      
      //initiating job object for bookmarking
      Job.init(args("JOB_NAME"), glueContext, args.asJava)
      
      log.info("Intiated GlueContext and all job parameters")
      
      val sntrTravelsDF=sparkSession.read.parquet(s"s3://${args("bucket_name")}/${args("landing_folder_sntr_travels")}/")
      val fyMonthDF=sparkSession.read.parquet(s"s3://${args("bucket_name")}/${args("landing_folder_fy_month")}/")
      val commodityMappingDF=sparkSession.read.parquet(s"s3://${args("bucket_name")}/${args("landing_folder_commodity_mapping")}/")
      val countryDF=sparkSession.read.parquet(s"s3://${args("bucket_name")}/${args("landing_folder_country")}/")
      
      sntrTravelsDF.createOrReplaceTempView("SNTR_Travel")
      fyMonthDF.createOrReplaceTempView("Month_Mapping")
      commodityMappingDF.createOrReplaceTempView("CAT_COM_Mapping")
      countryDF.createOrReplaceTempView("Country2")
      
      val sqlString="""
                    |with a as (select ESN as ESN_Corporate, Standort as Location, Business_Unit, SAP_System, Month_Mapping.Month,
                    |                  ifa_nummer as IFA_Number,lieferantenname_bl as Supplier_name, Country2.Country_New as Country,
                    |                  Country2.Lead_Country, Country2.Region, bezeichnung_bestellung_o_px as designation, Leistungsart as Activity_Type,
                    |                  Bestellnummer as Order_Number, Volume, Orders, Division,Fiscal_Year , SNTR_Travel.Commodity ,'Travel' as Source
                    |           from SNTR_Travel
                    |           left outer join Month_Mapping on SNTR_Travel.Period=Month_Mapping.Month_Number
                    |           left outer join Country2 on SNTR_Travel.Nation_BL=Country2.Country)
                    |select Fiscal_Year, Month , Division, Business_Unit, 'null' as Business_Unit_Description, 'No Company Code (CC)' as Company_Code,
                    |'No ARE-Code' as ARE_Code,Activity_Type,Lead_Country,'No Supplier Number' as Supplier_Number, Supplier_name,
                    |IFA_Number, 'No IFA Supplier Name' as IFA_Supplier_Name,  Commodity, '3rd Party Purchase' as Consolidated_Step_PVO,
                    |cast('0000' as float) as Volume_in_EUR, ESN_Corporate, 'No Description (material)' as Description_of_material,
                    |'No Gvs Step' as GVS_Step,'No Profit center (invoice)' as Profit_center_invoice,'No One SRM' as One_SRM,
                    |'No Purchase order number' as Purchase_order_number,Order_Number,'No Invoice posotin' as Invoice_position,
                    |'No OneSRM Flag' as OneSRM_Flag,'No Touch Flag' as No_Touch_Flag, 'No Touch Flag Description' as No_Touch_Flag_Description,
                    |Country,Region,'No Risk' as Risk,'No Contract' as Contract,'No SQ Status' as SQ_Status,'No Module' as Module,'Null' as Status,
                    |cast('0000' as float) as CHINA_Exclusion_Volume,cast('0000' as float) as PVO_non_China_Exclusion,'Null' as SQSTATUSnew,'Null' as Contract_Expiry_New,
                    |cast('0000' as float) as PVO_Exclusion, Source,'PO_Volume_Aging','Supplier_Aging','Supplier_creation_date','STATUS_NAME'
                    |from a        
                    """.stripMargin
                    
      val pvocvoViewTempA= sparkSession.sql(sqlString)
      
      pvocvoViewTempA.coalesce(args("partition_count").toInt).write.mode(SaveMode.Overwrite).format(args("format")).save(s"s3://${args("bucket_name")}/views/${args("staging_folder")}/")
      Job.commit()
    }
    catch {
       case x: Exception =>{ log.error(x.getStackTraceString)}
     
    }
    finally{
      sparkContext.hadoopConfiguration.set("mapred.output.committer.class", "org.apache.hadoop.mapred.FileOutputCommitter")
      log.info(s"the value of log destination : s3://gbs-p2p-logistics-staging-dev/logs/${jobId}/")
      log.info(s"the value of job_id: ${jobId}")
      val srcPath=new Path("/var/log/spark/apps/")
      val sourceFS=FileSystem.get(srcPath.toUri(), sparkContext.hadoopConfiguration)
      val desPath=new Path(s"s3://gbs-p2p-logistics-staging-dev/logs/${jobId}/")
      val destinationFS=FileSystem.get(desPath.toUri(),sparkContext.hadoopConfiguration)
      FileUtil.copy(sourceFS, srcPath, destinationFS, desPath, false, false, sparkContext.hadoopConfiguration)
      log.info("Stopping spark context")
      sparkContext.stop()
    }
   
  }
}